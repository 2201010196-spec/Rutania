---
name: Andean Heritage Modernism
colors:
  surface: '#fbf9f4'
  surface-dim: '#dbdad5'
  surface-bright: '#fbf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3ee'
  surface-container: '#f0eee9'
  surface-container-high: '#eae8e3'
  surface-container-highest: '#e4e2dd'
  on-surface: '#1b1c19'
  on-surface-variant: '#444939'
  inverse-surface: '#30312e'
  inverse-on-surface: '#f2f1ec'
  outline: '#747967'
  outline-variant: '#c4c9b4'
  surface-tint: '#496800'
  primary: '#476500'
  on-primary: '#ffffff'
  primary-container: '#5d7f13'
  on-primary-container: '#faffe7'
  inverse-primary: '#add461'
  secondary: '#725a39'
  on-secondary: '#ffffff'
  secondary-container: '#fbdbb0'
  on-secondary-container: '#765f3d'
  tertiary: '#b90728'
  on-tertiary: '#ffffff'
  tertiary-container: '#dd2c3d'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#c8f17a'
  primary-fixed-dim: '#add461'
  on-primary-fixed: '#131f00'
  on-primary-fixed-variant: '#364e00'
  secondary-fixed: '#feddb3'
  secondary-fixed-dim: '#e1c299'
  on-secondary-fixed: '#281801'
  on-secondary-fixed-variant: '#584324'
  tertiary-fixed: '#ffdad8'
  tertiary-fixed-dim: '#ffb3b1'
  on-tertiary-fixed: '#410007'
  on-tertiary-fixed-variant: '#92001c'
  background: '#fbf9f4'
  on-background: '#1b1c19'
  surface-variant: '#e4e2dd'
typography:
  headline-xl:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 32px
  stack-xl: 64px
---

## Brand & Style

The visual identity of the design system is anchored in the concept of **"Territory & Tranquility."** It bridges the gap between the rugged, ancient landscapes of the Cañete and Yauyos regions and the professional reliability of a modern virtual travel agency. The brand personality is human-centric, acting as a knowledgeable local guide rather than a faceless booking platform.

The design style follows a **Modern/Minimalist** approach with **Tactile** influences. It avoids the cold, clinical feel of typical tech startups by utilizing a warm color palette and soft geometric shapes. The goal is to evoke an emotional response of security, curiosity, and respect for nature. Every interface element should feel intentional and grounded, mirroring the stability of the mountains and the fluidity of the rivers.

## Colors

The color palette is derived directly from the Andean landscape and the brand's floral emblem.

- **Primary (Moss Green):** Used for primary actions, navigation headers, and active states. It represents sustainability and the lush valleys of the region.
- **Secondary (Sand/Beige):** Used for secondary UI elements, tonal backgrounds, and dividers. It provides a warm, earthy connection to the territory.
- **Neutral (Cream/Alabaster):** The core background color. It is softer than pure white, reducing eye strain and enhancing the "human" feel of the interface.
- **Accents (Andean Flora):** Discrete use of Red (from the logo) for critical alerts or specific call-to-outs, and soft Cyan or Yellow for iconography and small decorative details.

High contrast is maintained by using a deep charcoal (`#2D2D2A`) for all primary text to ensure maximum readability against the cream and sand backgrounds.

## Typography

This design system utilizes a dual-font strategy to balance professional structure with an approachable tone.

**Manrope** is used for all headlines. Its geometric but refined construction provides the "sober and modern" authority required for a travel agency. It scales beautifully from large hero sections to compact section headers.

**Be Vietnam Pro** is used for body text and labels. Its contemporary and warm character makes long-form content about travel destinations easy to digest and friendly to the eye. 

Large headings (XL and LG) should utilize a slightly tighter letter-spacing to appear more "editorial" and premium. Body text should maintain a generous line height (1.5x or higher) to support the "breathable" composition requested.

## Layout & Spacing

The layout is built on a **12-column fluid grid** for desktop and a **4-column grid** for mobile. The philosophy is centered on "Generous Whitespace," ensuring that the breathtaking photography of Peru is never crowded by UI elements.

- **Vertical Rhythm:** A base 8px unit governs all spacing. Use `stack-xl` to separate major content sections to create a sense of calm and order.
- **Margins:** Large horizontal margins on desktop (64px) prevent content from feeling "trapped" against the screen edges.
- **Alignment:** Use structured, professional alignments. Text-heavy blocks should be left-aligned for readability, while hero sections can utilize centered compositions for a more cinematic feel.

## Elevation & Depth

To maintain the "sober" and "natural" aesthetic, this design system avoids heavy shadows and floating effects. Instead, it uses **Tonal Layers** and **Low-Contrast Outlines**.

- **Surface Levels:** The primary background is the neutral cream. Content containers (like cards or sidebars) use a slightly darker sand tint or a pure white surface with a subtle 1px border in a muted earth tone.
- **Depth:** When depth is required (e.g., a modal or a floating action button), use a very soft, diffused ambient shadow with a hint of the primary green in the shadow's color profile (`rgba(107, 142, 35, 0.08)`). This creates a "lifted from the earth" effect rather than a digital glow.

## Shapes

The shape language is **Rounded (Value 2)**, featuring a standard 0.5rem (8px) corner radius. This choice avoids the clinical feel of sharp corners while remaining more professional and "grown-up" than fully pill-shaped components.

The 0.5rem radius should be applied to buttons, input fields, and cards. For larger containers or imagery, `rounded-xl` (1.5rem) may be used to emphasize the "soft and human" brand pillar. Iconography should follow a similar language, utilizing rounded terminals rather than sheared or pointed edges.

## Components

**Buttons:**
Primary buttons use the Moss Green background with white text. Secondary buttons use a Sand-colored border with Moss Green text. Hover states should involve a subtle shift in tonal depth rather than a dramatic color change.

**Cards:**
Travel destination cards should prioritize imagery. Use a 1px border (`#E5E0D5`) and no shadow. Text content within the card should have generous internal padding (min 24px) to maintain the "breathable" aesthetic.

**Input Fields:**
Fields should have a Sand-colored background (`#F0EDE5`) when inactive and a Moss Green border when focused. This reinforces the earthy connection even during data entry.

**Chips/Tags:**
Used for categories like "Sustainable," "Rural," or "Adventure." These should use low-saturation versions of the accent colors from the floral logo (e.g., a pale yellow background with dark yellow text) to remain discrete.

**Lists:**
Lists in tour itineraries should use custom icons derived from the geometric floral motif of the logo, rather than standard bullets, to reinforce the unique Andean heritage.